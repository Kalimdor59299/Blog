<?php
require_once 'config/init.conf.php';
require_once 'include/fonctions.inc.php';
require_once 'config/bdd.conf.php';
require_once 'config/connexion.conf.php';
include_once 'include/header.inc.php';

if (isset($_GET['recherche'])) {
?>


<div class="container">
    <div class="row">
        <h1 class="mt-5">Rechercher un article</h1>
        <?php
        $page_courante = empty($_GET['p']) ? 1 : $_GET['p'];


        $nb_total_articles = nb_total_article_publie_recherche($_GET['recherche'], $bdd);

        $nb_page = ceil($nb_total_articles / _nb_art_par_page);

        //Requête de sélection de articles

        $select_articles = "SELECT "
                . "id, "
                . "titre, "
                . "texte, "
                . "DATE_FORMAT(date, %d/%m/%Y') as date, "
                . "publie "
                . "FROM table1 "
                . "WHERE publie :publie "
                . "AND (titre LIKE :recherche OR texte LIKE :recherche) "
                . "LIMIT :index, :nb_article_par_page";
        /* var $bdd PDO */

//Préparation de la requête à exécuter
        $sth = $bdd->prepare($select_articles);
//Sécurisation des paramètres
        $sth->bindValue(':publie', 1, PDO::PARAM_BOOL);
        $sth->bindValue(':nb_article_par_page', _nb_art_par_page, PDO::PARAM_INT);
        $sth->bindValue(':index', $index, PDO::PARAM_INT);
        $sth->bindValue(':recherche', '%' . $_GET['recherche'] . '%', PDO::PARAM_STR);
        $sth->execute();
        $tab_result = $sth->fetchAll(PDO::FETCH_ASSOC); /* Pousse les résultats de notre requete SQL */
//print_r2($tab_result);
//echo $tab_result[0] ['titre'];
}
        ?>
    </div>
    
    
