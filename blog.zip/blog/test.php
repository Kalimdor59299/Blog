<?php

/* Bibliothèques */	
require_once 'config/bdd.conf.php';
require_once 'includes/fonctions.inc.php';
require_once 'includes/mail.php';
include "config/connexion.inc.php";
include "includes/header.php";

ini_set('display_errors','off');
?>


<?php

if($is_connect != true){
	
	/*
	*	Si l'utilisateur n'est pas connecté alors on le redirige vers la page de connexion
	*/
	
    header('Location: index.php');
    exit();
}

session_start();
$demandeur = $requser; //on récupère le nom de session du demandeur depuis le fichier connexion.inc.php


//LDAP Bind paramters, need to be a normal AD User account.
$ldap_password = "ld@p2018";
$ldap_username = "CN=ldap,OU=PB-Users,DC=PBDK,DC=local";
$server = "ldaps://vs-ad1/";
$port = "636";
$ldap_connection = ldap_connect($server,$port);
	 
if (FALSE === $ldap_connection){
    // Uh-oh, something is wrong...
	echo 'Unable to connect to the ldap server';
}


// We have to set this option for the version of Active Directory we are using.
ldap_set_option($ldap_connection, LDAP_OPT_PROTOCOL_VERSION, 3) or die('Unable to set LDAP protocol version');
ldap_set_option($ldap_connection, LDAP_OPT_REFERRALS, 0); // We need this for doing an LDAP search.
 
if (TRUE === ldap_bind($ldap_connection, $ldap_username, $ldap_password)){
 
 //Your domains DN to query
    $ldap_base_dn = 'OU=PB-Users,DC=PBDK,DC=local';
  
 //Get standard users and contacts
    $search_filter = '(|(objectCategory=person))';
  
 //Connect to LDAP
 $result = ldap_search($ldap_connection, $ldap_base_dn, $search_filter);
  
    if (FALSE !== $result){
 $entries = ldap_get_entries($ldap_connection, $result);
  
 // Uncomment the below if you want to write all entries to debug somethingthing 
 //var_dump($entries);

 //Create a table to display the output 
 echo '<br><center><h2>Liste des utilisateurs</h2></center></br>';
?>


<html>
        <div class="table-responsive" style="overflow-x: unset;">
        </div>

</html>


<?php
	echo ' 
		<div class="table-responsive" style="overflow-x: unset;">
           <table id "myTable" datatable="ng" dt-options="vm.dtOptions" class="table table-bordered table-striped">
           <thead>
				<!-- Name of the tables -->
				<tr>
					<th><center>Nom utilisateur</center></th>
					<th><center>Nom</center></th>
					<th><center>Prénom</center></th>
					<th><center>Établissement</center></th>
					<th><center>Profession</center></th>
					<th><center>Date expiration</center></th>
					<th><center>Statut</center></th>
					<th><center>Action</center></th>
				</tr>
           </thead></center>
		</div><form>';



  if (isset($_POST['submit'])) { 
	$ldaprecord['samaccountname'] = $LDAP_samaccountname;
	$ldaprecord['useraccountcontrol'] = "0x0202";

  }

 //Pour chaque compte retourné par la recherche
 
 for ($x=0; $x<$entries['count']; $x++){
  
 //
 //Récupère les valeurs depuis Active Directory
 //
  
   
 //Nom de session utilisateur
 
 $LDAP_samaccountname = "";
  
 if (!empty($entries[$x]['samaccountname'][0])) {
	$LDAP_samaccountname = $entries[$x]['samaccountname'][0];
	if ($LDAP_samaccountname == "NULL"){
		$LDAP_samaccountname= "";
	}
 } 
  
 //Nom
 
 $LDAP_LastName = "";
  
 if (!empty($entries[$x]['sn'][0])) {
	$LDAP_LastName = $entries[$x]['sn'][0];
	if ($LDAP_LastName == "NULL"){
		$LDAP_LastName = "";
 }
 }
  
 //Prénom
 
 $LDAP_FirstName = "";
  
 if (!empty($entries[$x]['givenname'][0])) {
	$LDAP_FirstName = $entries[$x]['givenname'][0];
	if ($LDAP_FirstName == "NULL"){
		$LDAP_FirstName = "";
 }
 }
  
 //Établissement/Entreprise
 
 $LDAP_CompanyName = "";
  
 if (!empty($entries[$x]['company'][0])) {
	$LDAP_CompanyName = $entries[$x]['company'][0];
	if ($LDAP_CompanyName == "NULL"){
		$LDAP_CompanyName = "";
 }
 }
 
 //Métier

 $LDAP_Description = "";
  
 if (!empty($entries[$x]['description'][0])) {
	$LDAP_Description = $entries[$x]['description'][0];
	if ($LDAP_CompanyName == "NULL"){
		$LDAP_CompanyName = "";
 }
 }

 //Date d'expiration
 
 $LDAP_AccountExpirationDate = "";

 if (!empty($entries[$x]['accountexpires'][0])) {
 $LDAP_AccountExpirationDate = $entries[$x]['accountexpires'][0];
// divide by 10.000.000 to get seconds from 100-nanosecond intervals
$winInterval = round($LDAP_AccountExpirationDate / 10000000);
// substract seconds from 1601-01-01 -> 1970-01-01
$unixTimestamp = ($winInterval - 11644473600);
// show date/time in local time zone
$date = date("d-m-Y", $unixTimestamp) ."\n";
  if ($LDAP_AccountExpirationDate == "9223372036854775807"){
 $date = "Jamais";
 }
 }
 
 //Statut du compte
 $LDAP_Status= "";
        
		if (!empty($entries[$x]['useraccountcontrol'][0])){
            $LDAP_Status = $entries[$x]['useraccountcontrol'][0];
			if ($LDAP_Status == "NULL"){
                $LDAP_Status = "";
            }
            if ($LDAP_Status == "16"){
                $LDAP_Status = "Verrouillé";
            }
            if ($LDAP_Status == "512"){
                $LDAP_Status = "Activé";
            }
            if ($LDAP_Status == "514"){
                $LDAP_Status = "Désactivé";
            }
            if ($LDAP_Status == "544"){
                $LDAP_Status = "Activé, mot de passe non requis";
            }
            if ($LDAP_Status == "546"){
                $LDAP_Status = "Désactivé, mot de passe non requis";
            }
            if ($LDAP_Status == "66048"){
                $LDAP_Status = "Activé, le mot de passe n'expire jamais";
            }
            if ($LDAP_Status == "66050"){
                $LDAP_Status = "Désactivé, le mot de passe n'expire jamais";
            }
			
			if ($LDAP_Status == "66080"){
            $LDAP_Status = "Activé, le mot de passe n'expire jamais et non requis";
            }
			
			if ($LDAP_Status == "66082"){
            $LDAP_Status = "Désactivé, le mot de passe n'expire jamais et non requis";
            }
        }

 echo "<tr>
			<td><center><strong>".$LDAP_samaccountname."</strong></center></td>
			<td><center>".$LDAP_LastName."</center></td>
			<td><center>".$LDAP_FirstName."</center></td>
			<td><center>".$LDAP_CompanyName."</center></td>
			<td><center>".$LDAP_Description."</center></td>
			<td><center>".$date."</center></td>
			<td><center>".$LDAP_Status."</center></td>
			<td><center><button type='submit' name='submit' class='btn btn-danger' value='$LDAP_samaccountname'>Désactiver</center></td></tr>
			";
 


 } //END for loop
 } //END FALSE !== $result

 ldap_unbind($ldap_connection); // Clean up after ourselves.
 echo("</form></table>"); //close the table
 // <td><center><button name='submit-$LDAP_samaccountname.' class='btn btn-danger'>Désactiver</button></center></td></tr>
} //END ldap_bind
?>