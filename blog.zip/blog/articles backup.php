<?php
require_once 'config/init.conf.php';
require_once 'include/fonctions.inc.php';
require_once 'config/bdd.conf.php';
require_once 'config/connexion.conf.php';
include_once 'include/header.inc.php';
print_r2($_SESSION);
/* @var $bdd PDO */


if (!empty($_POST['submit'])) {
    print_r2($_POST);
    print_r2($_FILES);

    $titre = $_POST['titre'];
    $texte = $_POST['texte'];

    $publie = isset($_POST['publie']) ? 1 : 0; #Cette commande est une version simplifiée de la suivante

    /* if (isset($_POST['publie'])) {
      $publie = 1;
      } else {
      $publie = 0;
      } */

    $date = date('Y-m-d');

    $sth = $bdd->prepare("INSERT INTO table1 " #Prépare une requête SQL
            . "(titre, texte, publie, date) "
            . "VALUES (:titre, :texte, :publie, :date)");
    $sth->bindValue(':titre', $titre, PDO::PARAM_STR);                          /* Associe une valeur à un nom correspondant 
      ou à un point d'interrogation (comme paramètre fictif)
      dans la requête SQL qui a été utilisé pour préparer la requête. */
    $sth->bindValue(':texte', $texte, PDO::PARAM_STR);
    $sth->bindValue(':publie', $publie, PDO::PARAM_BOOL);
    $sth->bindValue(':date', $date, PDO::PARAM_STR);

    $sth->execute(); #Exécute une requête préparée.

    $id_article = $bdd->lastInsertId();

    if ($_FILES['img']['error'] == 0) {
        move_uploaded_file($_FILES['img']['tmp_name'], 'img/' . $id_article . '.jpg'); #Récupère l'image où elle est située et la place dans le répertoire img/ et seulement du jpg
    }

    //déclaration de variable de session
    $message = 'Votre article a été ajouté.'; #Message de confirmation
    $result = 'success'; #Savoir si la requête a été réalisée ou non

    declareNotification($message, $result);

    header("Location: index.php"); //redirection, elle doit mettre en dernier car le script ne s'arrête pas même après cette ligne, on applique la redirection que lorsque le script fonctionne réellement
    exit(); //permet de stopper le script
}
?>

<!-- Page Content -->
<div class="container">
    <div class="row">
        <div class="col-lg-12 text-center">

            <h1 class="mt-5">Ajouter un article</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <form method="POST" action="articles.php" enctype="multipart/form-data" >
                <div class="form-group">
                    <label for="titre">Titre de votre article</label>
                    <input type="text" class="form-control" id="titre" placeholder="Entrez le titre ici" name='titre'> 
                </div>
                <div class="form-group">
                    <label for="texte">Contenu de l'article</label>
                    <textarea class="form-control" id="texte" rows="3" name='texte'></textarea>
                </div>
                <div class="form-group">
                    <label for="img">Image de l'article</label>
                    <input type="file" class="form-control-file" id="img" name='img'>
                </div>
                <div class="form-group form-check">
                    <input type="checkbox" class="form-check-input" id="publie" name='publie'>
                    <label class="form-check-label" for="publie">L'article doit être publié</label>
                </div>
                <button type="submit" class="btn btn-primary" name="submit" value="bouton" >Valider</button>
            </form>
        </div>
    </div>
</div>

<!-- Bootstrap core JavaScript -->
<script src="vendor/jquery/jquery.slim.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>