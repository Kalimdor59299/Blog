<?php

function print_r2($ma_variable) {
    echo '<pre>';
    print_r($ma_variable);
    echo '</pre>';

    return true;

    /* @var bdd PDO */
}

function DeclareNotification($message, $result) {
    $_SESSION['notification']['message'] = $message; #Message de confirmation
    $_SESSION['notification']['result'] = $result; #Savoir si la requête a été réalisée ou non

    return TRUE;
}

function countArticle($bdd) {
    /* @var $bdd PDO */
    $sth = $bdd->prepare("SELECT COUNT(*) as total "
            . "FROM table1 "
            . "WHERE publie = :publie");
    $sth->bindValue(':publie', 1, PDO::PARAM_BOOL);
    $sth->execute();
    $result = $sth->fetch(PDO::FETCH_ASSOC);

    return $result['total'];
}

function returnIndex($page_courante, $nb_articles_par_page) {
    $index_depart = (($page_courante - 1) * $nb_articles_par_page);

    return $index_depart;
}
