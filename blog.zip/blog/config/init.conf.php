<?php

session_start(); #Permet sur toutes les pages d'initialiser les sessions
//Affichage des erreurs et avertissements PHP
error_reporting(E_ALL);
ini_set("display_errors", 1);

define('_nb_articles_par_page', 2); #constante qui définit le nombre d'articles par page



date_default_timezone_set('Europe/Paris'); #Heure du serveur 


