<?php

/**
* Fichier de connexion utilisateur
*
* Permet de savoir si un utilisateur s'est deja connecté sur le site grâce au cookie
* et affiche une notification sur chaque page pour indiquer que l'utilisateur est connecté
* 
* Contenu :
* 
* Notification avec le nom et prénom de la personne connectée
* Variable $is_connect et $is_admin; qui permet de restreindre l'affichage de certaines fonctionnalitées (barre de navigation+page)
* ou de pages sur le site entre un utilisateur connecté et non connecté 
*
**/

/* On définit par défaut que l'utilisateur arrivant sur la page est deconnecté */
$is_connect = false;

/* On définit par défaut que l'utilisateur arrivant sur la page ne peut pas accéder à la page du tableau statistiques */
$is_admin = false;


/* La variable $sid prend la valeur du cookie portant l'index sid-pbdk-ldap s'il existe sinon le sid est vide */
$sid = isset($_COOKIE['sid-pbdk-ldap']) ? $_COOKIE['sid-pbdk-ldap'] : "";

if ($sid != "") {
	/**
	* Si la variable sid est différent de vide on suit ces instructions
	*/

	/* On crée une requête pour aller chercher le nom de session de l'utilisateur correspondant au sid  */
	$selectsid = "SELECT user "
			   . "FROM utilisateurs "
			   . "WHERE sid = :sid;";
									   
	/* On prépare la requete la requête select */
	$sth = $bdd->prepare($selectsid);
	/* On associe la valeur du sid au paramétre sid de la base de données */
	$sth->bindValue(':sid', $sid, PDO::PARAM_STR);

	if($sth->execute() == TRUE){
		/**
		*Si la requête s'execute correctement, on suit ces instructions 
		*/

		/* On compte le nombre de ligne trouvé avec la requête selectsid */
		$count = $sth->rowCount();

		if($count > 0){
			/**
			*Si la requête contient au moins une ligne alors on suit ces intructions
			*/

			/* On met la variable is_connect à true pour indiquer que l'utilisateur est connecté */
			$is_connect = true;

			/* On récupère le nom de session pour aller chercher son nom et prénom avec ldap*/

			if($donnees1 = $sth->fetch()){

				$requser = $donnees1['user'];

				//Eléments d'authentification LDAPS
				$server = "ldaps://vs-ad1/";
				$port = "636";

				// Nom d'utilisateur et mot de passe du compte possédant les droits pour lire dans l'AD (Admin du domaine)
				$ldapdn = "CN=ldap,OU=PB-Users,DC=PBDK,DC=local";
				$ldappass = "ld@p2018";

				//Emplacement de l'utilisateur à chercher dans l'AD
				$dn_User =  "CN=".$requser.",OU=PB-Users,DC=PBDK,DC=local" ;

				//connexion ldap securisée
				$ldap=ldap_connect($server,$port);

				if($ldap){
						
					ldap_set_option ($ldap, LDAP_OPT_PROTOCOL_VERSION, 3);
					ldap_set_option($ldap, LDAP_OPT_REFERRALS, 0);
					//identification avec compte admin
					$ldapbind = ldap_bind($ldap,$ldapdn,$ldappass);

					if($ldapbind){
						
						/**
						* Si la connexion ldaps fonctionne, on suit les instructions ci-dessous
						*
						**/
						
						/* Filtre DisplayName(nom de session) */
						$filter="(objectclass=*)";
						$justthese = array("displayName");

						$sr=ldap_read($ldap, $dn_User, $filter, $justthese);
						$entry = ldap_get_entries($ldap, $sr);

						/* On récupère le nom et prénom de l'utilisateur si le nom de session existe dans l'AD */
						$usercon = $entry[0]["displayname"][0];

						/* Ferme la connexion LDAPS*/
						ldap_close($ldap);

						/* Requête select, elle va permettre d'aller lire la variable admin d'un utilisateur dans la BDD */
						$select = "SELECT admin "
						."FROM utilisateurs "
						."WHERE user = :user;";

						/* Préparation de la requête select */
						$sth = $bdd->prepare($select);
						/* On définit les variables de la requête */
						$sth->bindValue(':user', $requser,  PDO::PARAM_STR);

						if($sth->execute() == TRUE){
							
							/**
							* Si la requête fonctionne, on suit les instructions ci-dessous
							*
							**/							
							
							$donnees = $sth->fetch();
							
							/* Attribue la valeur 1 à $is_admin */

							if($donnees['admin'] == "1" || $donnees['admin'] == "2" ){
								
								$is_admin = TRUE;

							}
						}else{

							echo "Erreur lors de la lecture de la variable admin de l'utilisateur connecté.";
							exit();
						}
					}else{

						echo 'Erreur Cookie : identifiants incorrects pour la connexion au serveur Ldap';
						exit();
					}					
				}else{

					echo 'Erreur Cookie : impossible de se connecter au serveur Ldap';
					exit();
				}
			}else{
				echo 'Erreur lors de la récupération du nom de session';
				exit();
			}
		}
	}else{		
		echo 'Erreur lors de la lecture du sid dans la BDD';
		exit();		
	}
}
                       
?>
