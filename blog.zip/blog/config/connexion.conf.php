<?php

/* @var $bdd PDO */
$connecte = FALSE;
//print_r2($_COOKIE);
if (isset($_COOKIE['sid'])) { //vérifie si le cookie sid existe, comparaison entre le cookie navigateur et le cookie bdd
    $sid = $_COOKIE['sid'];
    $sth_connexion = $bdd->prepare("SELECT * "
            . "FROM utilisateur "
            . "WHERE sid = :sid ");
    $sth_connexion->bindValue(':sid', $sid, PDO::PARAM_STR);
    $sth_connexion-->execute();
    //Si on récupère le cookie alors connexion réussie
    if ($sth_connexion->rowCount() > 0) {
        $connecte = TRUE;
    }
}