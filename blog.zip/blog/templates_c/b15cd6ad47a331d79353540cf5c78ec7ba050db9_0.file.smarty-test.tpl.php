<?php
/* Smarty version 3.1.34-dev-7, created on 2019-12-20 13:49:34
  from 'C:\xampp\htdocs\blog\templates\smarty-test.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5dfcc35ea416a4_60874104',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b15cd6ad47a331d79353540cf5c78ec7ba050db9' => 
    array (
      0 => 'C:\\xampp\\htdocs\\blog\\templates\\smarty-test.tpl',
      1 => 1576846172,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5dfcc35ea416a4_60874104 (Smarty_Internal_Template $_smarty_tpl) {
?><h1>Mon prénom est <?php echo $_smarty_tpl->tpl_vars['prenom']->value;?>
</h1><?php }
}
