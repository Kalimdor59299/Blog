<?php
/* Bibliothèques */
require_once 'config/bdd.conf.php';
require_once 'includes/fonctions.inc.php';
require_once 'includes/mail.php';
include "config/connexion.inc.php";
include "includes/header.php";

ini_set('display_errors', 'off');

if ($is_connect != true) {

    /*
     * 	Si l'utilisateur n'est pas connecté alors on le redirige vers la page de connexion
     */

    header('Location: index.php');
    exit();
}
session_start();
$demandeur = $requser; //on récupère le nom de session du demandeur depuis le fichier connexion.inc.php
//Paramètres de connexion au serveur LDAP

$ldap_password = "ld@p2018";
$ldap_username = "CN=ldap,OU=PB-Users,DC=PBDK,DC=local";
$server = "ldaps://vs-ad1/";
$port = "636";
$ldap_connection = ldap_connect($server, $port);

//Si la connexion au serveur AD échoue, on affiche le message suivant
if (FALSE === $ldap_connection) {

    echo 'Impossible de se connecter au serveur';
}


ldap_set_option($ldap_connection, LDAP_OPT_PROTOCOL_VERSION, 3) or die('Unable to set LDAP protocol version');
ldap_set_option($ldap_connection, LDAP_OPT_REFERRALS, 0); // We need this for doing an LDAP search.
//Si la connexion au serveur AD est établie, on utilise les paramètres suivants
if (TRUE === ldap_bind($ldap_connection, $ldap_username, $ldap_password)) {

    //Le groupe d'utilisateurs qu'on veut interroger
    $ldap_base_dn = 'OU=PB-Users,DC=PBDK,DC=local';

    //Récupère les utilisateurs/contacts
    $search_filter = '(|(objectCategory=person))';

    //Connexion au LDAP
    $result = ldap_search($ldap_connection, $ldap_base_dn, $search_filter);

    if (FALSE !== $result) {
        $entries = ldap_get_entries($ldap_connection, $result);

        // Uncomment the below if you want to write all entries to debug something
        //var_dump($entries);


        if (isset($_POST['submit'])) {
            /**
             * Si la valeur submit a été postée alors on suit ces
             * instructions.
             */
            foreach ($_POST['NomUtilisateur'] as $NomUtilisateur) {       //On récupère le nom de l'utilisateur qu'on souhaite désactiver
                $dn_User = "CN=" . $NomUtilisateur . ",OU=PB-Users,DC=PBDK,DC=local";  //Récupère l'emplacement de l'utilisateur sur l'AD
                $ldaprecord["useraccountcontrol"] = "514";
                $requete = ldap_mod_replace($ldap_connection, $dn_User, $ldaprecord);  //Change  le statut du compte en désactivé
                RequeteLDAP($requete);
            }
            $notification = "La ou les sessions ont étés désactivées.";
            $_SESSION['notification'] = $notification;
            header('Location: desacuser.php');
            exit();
        }
        ?>

        <!-- Page Content -->
        <!-- Bouton revenir vers le haut -->
        <style>
            #scrollUp
            {
                position: fixed;
                bottom : 10px;
                right: -100px;
                opacity: 0.5;
            }
        </style>

        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8/jquery.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

        <script>
            jQuery(function () {
                $(function () {
                    $(window).scroll(function () {
                        if ($(this).scrollTop() > 200) {
                            $('#scrollUp').css('right', '10px');
                        } else {
                            $('#scrollUp').removeAttr('style');
                        }

                    });
                });
            });
        </script>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <br/>
                    <p class="lead">Veuillez cocher la(les) session(s) que vous souhaitez désactiver.</p>

                    <!-- On récupère une notification s'il elle n'est pas vide -->

        <?php
        if (isset($_SESSION['notification'])) {

            $notification_result = $_SESSION['notification_color'] == TRUE ? 'alert-success' : 'alert-danger';
            ?>
                        <div class="alert <?= $notification_result; ?> alert-dismissible fade show" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
            <?= $_SESSION['notification']; ?>              
                        </div>
                            <?php
                            unset($_SESSION['notification']);
                            unset($_SESSION['notification_color']);
                        }
                        ?>
                    <!-- Formulaire de connexion -->
                    <form action="desacuser.php" method="post" enctype="multipart/form-data" id="form-connexion">
                        <!-- Champs nom de session -->
                        <div class="form-group">
                            <label for="demandeur">Demandeur :</label>
                            <input type="text" class="form-control" name="demandeur" value="<?= $demandeur; ?>" disabled="disabled" />
                        </div>
                        <!-- <div class="form-group">
                            <label for="demandeur">Nom de session :</label>
                            <input  type="text" class="form-control" name="username" id="username" placeholder="p.nom" required>
                                                    <br/>
                        </div> -->
                        <!-- Bouton désactiver -->
                        <div class="row justify-content-center">

                            <!-- Bouton pour désactiver la session -->
                            <button type="button" class="btn btn-danger btn-lg" data-toggle="modal" data-target="#myModal">
                                Désactiver la session
                            </button>

                            <!-- Pop-up avertissement -->
                            <div class="modal fade" id="myModal">
                                <div class="modal-dialog">
                                    <div class="modal-content">

                                        <!-- En-tête pop-up -->
                                        <div class="modal-header">
                                            <h4 class="modal-title">Avertissement</h4>
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        </div>

                                        <!-- Message du pop-up -->
                                        <div class="modal-body">
                                            Êtes-vous sûr de désactiver cette/ces session(s) ?
                                        </div>

                                        <!-- Pop-up footer -->
                                        <div class="modal-footer">
                                            <button type="submit" name="submit" class="btn btn-danger">Confirmer</button>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>	
                </div>
            </div>
        </div>

        <div class="container">



        </div>
        <?php
        //Créer un tableau pour afficher la liste des utilisateurs
        echo '<br><center><h2>Liste des utilisateurs</h2></center></br>
		<input class="form-control" id="myInput" type="text" placeholder="Filtrer par nom de session, nom, prénom, établissement, profession...">
		<br>
		<br>
		';
        ?>


        <html>
            <head>
                <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
                <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
            <div class="table-responsive" style="overflow-x: unset;">
            </div>
            <div id="scrollUp">
                <a href="#top"><img src="img/to_top.png"/></a>
            </div>
        </head>
        </html>


        <?php echo ' 
		<div class="table-responsive" style="overflow-x: unset;">
		   <table datatable="ng" dt-options="vm.dtOptions" class="table table-bordered table-striped">
           <thead>
				<tr>
					<th><center>Action</center></th>
					<th><center>Nom utilisateur</center></th>
					<th><center>Nom</center></th>
					<th><center>Prénom</center></th>
					<th><center>Établissement</center></th>
					<th><center>Profession</center></th>
					<th><center>Date expiration</center></th>
					<th><center>Statut</center></th>
				</tr>
           </thead></center>
		</div>'; ?>



        <?php
        //Pour chaque compte retourné par la recherche

        for ($x = 0; $x < $entries['count']; $x++) {

            //
            //Récupère les valeurs depuis Active Directory
            //
            //Nom de session utilisateur

            $LDAP_samaccountname = "";

            if (!empty($entries[$x]['samaccountname'][0])) {
                $LDAP_samaccountname = $entries[$x]['samaccountname'][0];
                if ($LDAP_samaccountname == "NULL") {
                    $LDAP_samaccountname = "";
                }
            }

            //Nom

            $LDAP_LastName = "";

            if (!empty($entries[$x]['sn'][0])) {
                $LDAP_LastName = $entries[$x]['sn'][0];
                if ($LDAP_LastName == "NULL") {
                    $LDAP_LastName = "";
                }
            }

            //Prénom

            $LDAP_FirstName = "";

            if (!empty($entries[$x]['givenname'][0])) {
                $LDAP_FirstName = $entries[$x]['givenname'][0];
                if ($LDAP_FirstName == "NULL") {
                    $LDAP_FirstName = "";
                }
            }

            //Établissement/Entreprise

            $LDAP_CompanyName = "";

            if (!empty($entries[$x]['company'][0])) {
                $LDAP_CompanyName = $entries[$x]['company'][0];
                if ($LDAP_CompanyName == "NULL") {
                    $LDAP_CompanyName = "";
                }
            }

            //Profession

            $LDAP_Description = "";

            if (!empty($entries[$x]['description'][0])) {
                $LDAP_Description = $entries[$x]['description'][0];
                if ($LDAP_CompanyName == "NULL") {
                    $LDAP_CompanyName = "";
                }
            }

            //Date d'expiration

            $LDAP_AccountExpirationDate = "";

            if (!empty($entries[$x]['accountexpires'][0])) {
                $LDAP_AccountExpirationDate = $entries[$x]['accountexpires'][0];
                // divide by 10.000.000 to get seconds from 100-nanosecond intervals
                $winInterval = round($LDAP_AccountExpirationDate / 10000000);
                // substract seconds from 1601-01-01 -> 1970-01-01
                $unixTimestamp = ($winInterval - 11644473600);
                // show date/time in local time zone
                $date = date("d-m-Y", $unixTimestamp) . "\n";
                if ($LDAP_AccountExpirationDate == "9223372036854775807") {
                    $date = "Jamais";
                }
            }

            //Statut du compte
            $LDAP_Status = "";

            if (!empty($entries[$x]['useraccountcontrol'][0])) {
                $LDAP_Status = $entries[$x]['useraccountcontrol'][0];
                if ($LDAP_Status == "NULL") {
                    $LDAP_Status = "";
                }
                if ($LDAP_Status == "16") {
                    $LDAP_Status = "Verrouillé";
                }
                if ($LDAP_Status == "512") {
                    $LDAP_Status = "Activé";
                }
                if ($LDAP_Status == "514") {
                    $LDAP_Status = "Désactivé";
                }
                if ($LDAP_Status == "544") {
                    $LDAP_Status = "Activé";
                }
                if ($LDAP_Status == "546") {
                    $LDAP_Status = "Désactivé";
                }
                if ($LDAP_Status == "66048") {
                    $LDAP_Status = "Activé";
                }
                if ($LDAP_Status == "66050") {
                    $LDAP_Status = "Désactivé";
                }

                if ($LDAP_Status == "66080") {
                    $LDAP_Status = "Activé";
                }

                if ($LDAP_Status == "66082") {
                    $LDAP_Status = "Désactivé";
                }
            }

            echo "<tbody id='myTable'><tr>
			<td><center><div class='checkbox'><input value=" . $LDAP_samaccountname . " name='NomUtilisateur[]' type='checkbox' ></div></center></td>
			<td><center><strong>" . $LDAP_samaccountname . "</strong></center></td>
			<td><center>" . $LDAP_LastName . "</center></td>
			<td><center>" . $LDAP_FirstName . "</center></td>
			<td><center>" . $LDAP_CompanyName . "</center></td>
			<td><center>" . $LDAP_Description . "</center></td>
			<td><center>" . $date . "</center></td>
			<td><center>" . $LDAP_Status . "</center></td></tr>
			";
        } //Fin de la boucle
    } //Fin du FALSE !== $result
    ldap_unbind($ldap_connection); // Déconnexion au serveur LDAP
    echo("</tbody></table></form>"); //Ferme le tableau
} //END ldap_bind
?>

<script>
            $(document).ready(function () {
                $("#myInput").on("keyup", function () {
                    var value = $(this).val().toLowerCase();
                    $("#myTable tr").filter(function () {
                        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                    });
                });
            });
</script>


